package outerhaven.spring;

public interface IMyAdvice {
	String test(int i, String s, float f);
}
