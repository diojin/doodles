package outerhaven.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("aopConfig.xml");
		IMyAdvice target = (IMyAdvice)context.getBean("aop1");
		target.test(10, "hah", 10.3f);
	}

}
